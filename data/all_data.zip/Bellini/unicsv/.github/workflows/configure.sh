#!/bin/bash

sudo apt install -y gcc-mingw-w64-x86-64
